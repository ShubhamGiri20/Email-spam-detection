# import numpy as np;
# import pandas as pd;
# import matplotlib.pyplot as plt
# from sklearn.preprocessing import LabelEncoder
# import nltk
# nltk.download('stopwords')
# nltk.download('PortStemmer')
# import sklearn.naive_bayes
# sklearn.naive_bayes.download('GaussianNB')
# from nltk.corpus import stopwords
# stopwords.words('english')
# import string
# string.punctuation
# from nltk.stem.porter import PorterStemmer
# ps=PorterStemmer()
# ps.stem('dancing')
# df=pd.read_csv('spam.csv')
# print(df.sample(5))
# print(df.shape)
# #1. data cleaning
# #2.EDA
# #3.text preprocessing
# #4.model building
# #5.evaluation
# #6.improvement
# #7.website
# #8.deploy

# #data cleaning

# # from sklearn.preprocessing import LabelEncoder
# # encoder=LabelEncoder()
# # df['category']=encoder.fit_transform(df['category'])
# # print(df.head())
# # print(df.info())

# #missing values
# print(df.isnull().sum())
# #check duplicate value
# print(df.duplicated().sum())
# #remove duplicate value
# df=df.drop_duplicates(keep='first')
# print(df.duplicated().sum())
# print(df.shape)

# #2. EDA
# print(df.head())
# print(df['Category'].value_counts())

# #make a pie chart

# plt.pie(df['Category'].value_counts(),labels=['ham','spam'],autopct="%0.2f")
# plt.show()

# #data is imbalance
# import nltk
# nltk.download('punkt')
# df['num_characters']=df['Message'].apply(len)
# print(df['num_characters'])
# print(df.head())
# #num of words
# df['num_words']=df['Message'].apply(lambda x:len(nltk.word_tokenize(x)))
# print(df['num_words'])
# print(df.head())
# df['num_sentences']=df['Message'].apply(lambda x:len(nltk.sent_tokenize(x)))
# print(df['num_sentences'])
# print(df.head())
# print(df[['num_characters','num_words','num_sentences']].describe())
# #ham 
# print(df[df['Category']=='ham'][['num_characters','num_words','num_sentences']].describe())
# #spam 
# print(df[df['Category']=='spam'][['num_characters','num_words','num_sentences']].describe())
# # Plot histogram of the number of characters in 'ham' and 'spam' messages

# import seaborn as sns
# sns.histplot(df[df['Category']=='ham']['num_characters'])
# sns.histplot(df[df['Category']=='spam']['num_characters'],color='red')
# plt.show()
# # Plot histogram of the number of words in 'ham' and 'spam' messages
# sns.histplot(df[df['Category']=='ham']['num_words'])
# sns.histplot(df[df['Category']=='spam']['num_words'],color='red')
# plt.show()
# sns.pairplot(df,hue='Category')
# plt.show()
# # sns.heatmap(df.corr(),annot=True)
# # plt.show()
# # numeric_df = df.select_dtypes(include=[np.number])
# # sns.heatmap(numeric_df.corr(), annot=True)
# # plt.show()

# # 3. Data reprocessing
# #lower case
# #tokenization
# #removing all special character
# #removing stop word and punchtuation
# #steaming
# def transform_Message(Message):
#     Message=Message.lower()
#     Message=nltk.word_tokenize(Message)
#     y=[]
#     for i in Message:
#         if i.isalnum():
#             y.append(i)
#     Message=y[:]
#     y.clear()
#     for i in Message:
#        if i not in stopwords.words('english') and i not in string.punctuation:
#           y.append(i)
#     Message=y[:]
#     y.clear()
#     for i in Message:
#         y.append(ps.stem(i))

#     return " ".join(y)

# print(transform_Message('HI how are you kanishka'))
# df['transform_Message']=df['Message'].apply(transform_Message)
# print(df.head())
# from wordcloud import wordcloud
# wc=wordcloud(width=50,height=50,min_font_size=10,background_color='white')
# spam_wc=wc.generate(df[df['Category']=='spam']['transform_Message'].str.cat(sep=" "))
# plt.imshow(spam_wc,interpolation='bilinear')
# plt.axis('off')
# plt.show()
# spam_corpus=[]
# for msg in df[df['Category']=='spam']['transform_Message'].to_list():
#     for word in msg.split():
#         spam_corpus.append(word)

# print(len(spam_corpus))
# from collections import Counter
# sns.barplot(pd.DataFrame(Counter(spam_corpus).most_common(30)[0],pd.DataFrame(Counter(spam_corpus).most_common(30))[1]))
# plt.xticks(rotation='vertical')
# plt.show()
# ham_corpus=[]
# for msg in df[df['Category']=='ham']['transform_Message'].tolist():
#     for word in msg.split():
#         ham_corpus.append(word)

# print(len(ham_corpus))
# from collections import Counter
# spam_counter = pd.DataFrame(Counter(spam_corpus).most_common(30), columns=['word', 'count'])
# ham_counter = pd.DataFrame(Counter(ham_corpus).most_common(30), columns=['word', 'count'])
# sns.barplot(pd.DataFrame(Counter(spam_corpus).most_common(30)[0],pd.DataFrame(Counter(spam_corpus).most_common(30))[1]))
# plt.xticks(rotation='vertical')
# plt.show()

# #model building
# from sklearn.feature_extraction.text import CountVectorizer
# cv=CountVectorizer()
# X=cv.fit_transform(df['transform_Message']).toarray()
# print(X.shape)
# y=df['Category'].values
# print(y)
# from sklearn.model_selection import train_test_split
# X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=2)

# from sklearn.naive_bayes import GaussianNB,MultinomialNB,BernoulliNB
# from sklearn.metrics import accuracy_score, confusion_matrix, precision_score
# # gnb=GaussianNB()
# # mnb=MultinomialNB()
# # bnb=BernoulliNB()
# # print(gnb.fit(X_train,y_train))
# # y_pred1=gnb.predict(X_test)
# # print(accuracy_score(y_test,y_pred1))
# # print(confusion_matrix(y_test,y_pred1))
# # print(precision_score(y_test,y_pred1))
# # Naive Bayes Models
# gnb = GaussianNB()
# mnb = MultinomialNB()
# bnb = BernoulliNB()
# # GaussianNB
# gnb.fit(X_train, y_train)
# y_pred1 = gnb.predict(X_test)
# print('GaussianNB:')
# print('Accuracy:', accuracy_score(y_test, y_pred1))
# print('Confusion Matrix:', confusion_matrix(y_test, y_pred1))
# print('Precision:', precision_score(y_test, y_pred1, pos_label='spam'))
# # MultinomialNB
# mnb.fit(X_train, y_train)
# y_pred2 = mnb.predict(X_test)
# print('MultinomialNB:')
# print('Accuracy:', accuracy_score(y_test, y_pred2))
# print('Confusion Matrix:', confusion_matrix(y_test, y_pred2))
# print('Precision:', precision_score(y_test, y_pred2, pos_label='spam'))

# # BernoulliNB
# bnb.fit(X_train, y_train)
# y_pred3 = bnb.predict(X_test)
# print('BernoulliNB:')
# print('Accuracy:', accuracy_score(y_test, y_pred3))
# print('Confusion Matrix:', confusion_matrix(y_test, y_pred3))
# print('Precision:', precision_score(y_test, y_pred3, pos_label='spam'))
# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn as sns
# from nltk.corpus import stopwords
# from nltk.stem.porter import PorterStemmer
# from nltk.tokenize import word_tokenize, sent_tokenize
# from wordcloud import WordCloud
# from sklearn.feature_extraction.text import CountVectorizer
# from sklearn.model_selection import train_test_split
# from sklearn.naive_bayes import GaussianNB, MultinomialNB, BernoulliNB
# from sklearn.metrics import accuracy_score, confusion_matrix, precision_score
# import nltk
# import string

# # Download necessary NLTK data
# nltk.download('stopwords')
# nltk.download('punkt')

# # Load data
# df = pd.read_csv('spam.csv')

# # Data cleaning
# print(df.isnull().sum())
# print(df.duplicated().sum())
# df = df.drop_duplicates(keep='first')
# print(df.shape)

# # Exploratory Data Analysis (EDA)
# print(df.head())
# print(df['Category'].value_counts())

# plt.pie(df['Category'].value_counts(), labels=['ham', 'spam'], autopct="%0.2f")
# plt.show()

# df['num_characters'] = df['Message'].apply(len)
# df['num_words'] = df['Message'].apply(lambda x: len(word_tokenize(x)))
# df['num_sentences'] = df['Message'].apply(lambda x: len(sent_tokenize(x)))
# print(df[['num_characters', 'num_words', 'num_sentences']].describe())

# # Histograms
# sns.histplot(df[df['Category'] == 'ham']['num_characters'], label='ham', kde=False, color='blue')
# sns.histplot(df[df['Category'] == 'spam']['num_characters'], label='spam', kde=False, color='red')
# plt.legend()
# plt.show()

# sns.histplot(df[df['Category'] == 'ham']['num_words'], label='ham', kde=False, color='blue')
# sns.histplot(df[df['Category'] == 'spam']['num_words'], label='spam', kde=False, color='red')
# plt.legend()
# plt.show()

# sns.pairplot(df, hue='Category')
# plt.show()

# # Text preprocessing
# ps = PorterStemmer()

# def transform_message(message):
#     message = message.lower()
#     message = word_tokenize(message)
#     message = [word for word in message if word.isalnum()]
#     message = [word for word in message if word not in stopwords.words('english') and word not in string.punctuation]
#     message = [ps.stem(word) for word in message]
#     return " ".join(message)

# df['transformed_Message'] = df['Message'].apply(transform_message)
# print(df.head())

# # Wordcloud
# wc = WordCloud(width=500, height=500, min_font_size=10, background_color='white')
# spam_wc = wc.generate(df[df['Category'] == 'spam']['transformed_Message'].str.cat(sep=" "))
# plt.imshow(spam_wc, interpolation='bilinear')
# plt.axis('off')
# plt.show()

# # Frequency distribution for spam and ham messages
# spam_corpus = []
# for msg in df[df['Category'] == 'spam']['transformed_Message'].tolist():
#     for word in msg.split():
#         spam_corpus.append(word)

# ham_corpus = []
# for msg in df[df['Category'] == 'ham']['transformed_Message'].tolist():
#     for word in msg.split():
#         ham_corpus.append(word)

# # Plot most common words
# from collections import Counter
# spam_counter = pd.DataFrame(Counter(spam_corpus).most_common(30), columns=['word', 'count'])
# ham_counter = pd.DataFrame(Counter(ham_corpus).most_common(30), columns=['word', 'count'])

# sns.barplot(x='word', y='count', data=spam_counter)
# plt.xticks(rotation='vertical')
# plt.show()

# sns.barplot(x='word', y='count', data=ham_counter)
# plt.xticks(rotation='vertical')
# plt.show()

# # Model building
# cv = CountVectorizer()
# X = cv.fit_transform(df['transformed_Message']).toarray()
# y = df['Category'].values

# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=2)

# # Naive Bayes Models
# gnb = GaussianNB()
# mnb = MultinomialNB()
# bnb = BernoulliNB()

# # GaussianNB
# gnb.fit(X_train, y_train)
# y_pred1 = gnb.predict(X_test)
# print('GaussianNB:')
# print('Accuracy:', accuracy_score(y_test, y_pred1))
# print('Confusion Matrix:', confusion_matrix(y_test, y_pred1))
# print('Precision:', precision_score(y_test, y_pred1, pos_label='spam'))

# # MultinomialNB
# mnb.fit(X_train, y_train)
# y_pred2 = mnb.predict(X_test)
# print('MultinomialNB:')
# print('Accuracy:', accuracy_score(y_test, y_pred2))
# print('Confusion Matrix:', confusion_matrix(y_test, y_pred2))
# print('Precision:', precision_score(y_test, y_pred2, pos_label='spam'))

# # BernoulliNB
# bnb.fit(X_train, y_train)
# y_pred3 = bnb.predict(X_test)
# print('BernoulliNB:')
# print('Accuracy:', accuracy_score(y_test, y_pred3))
# print('Confusion Matrix:', confusion_matrix(y_test, y_pred3))
# print('Precision:', precision_score(y_test, y_pred3, pos_label='spam'))
# #tfidf --->MNB
# from sklearn.linear_model import LogisticRegression
# from sklearn.svm import SVC
# from sklearn.naive_bayes import MultinomialNB
# from sklearn.tree import DecisionTreeClassifier
# from sklearn.neighbors import KNeighborsClassifier
# from sklearn.ensemble import RandomForestClassifier
# from sklearn.ensemble import AdaBoostClassifier
# from sklearn.ensemble import BaggingClassifier
# from sklearn.ensemble import ExtraTreesClassifier
# from sklearn.ensemble import GradientBoostingClassifier
# from xgboost import XGBClassifier
# svc=SVC(kernel='sigmoid',gamma=1.0)
# knc=KNeighborsClassifier()
# mnb=MultinomialNB
# dtc=DecisionTreeClassifier(max_depth=5)
# lrc=LogisticRegression(solver='liblinear',penalty='l1')
# rfc=RandomForestClassifier(n_estimators=50,random_state=2)
# abc=AdaBoostClassifier(n_estimators=50,random_state=2)
# bc=BaggingClassifier(n_estimators=50,random_state=2)
# etc=ExtraTreesClassifier(n_estimators=50,random_state=2)
# gbdt=GradientBoostingClassifier(n_estimators=50,random_state=2)
# xgb=XGBClassifier(n_estimators=50,random_state=2)
# clfs={
#     'SVC':svc,
#     'KN':knc,
#     'NB':mnb,
#     'DT':dtc,
#     'LR':lrc,
#     'RF':rfc,
#     'AdaBoost':abc,
#     'Bgc':bc,
#     'ETC':etc,
#     'GBDT':gbdt,
#     'xgb':xgb
# }
# # def train_classifier(clf,X_train,y_train,X_test,y_test):
# #     clf.fit(X_train,y_train)
# #     y_pred=clf.predict(X_test)
# #     accuracy=accuracy_score(y_test,y_pred)
# #     precision=precision_score(y_test,y_pred)
# #     return accuracy,precision


# # svc =SVC()
# # xgb=XGBClassifier()
# # svc_accuracy, svc_precision = train_classifier(svc, X_train, y_train, X_test, y_test)
# # xgb_accuracy, xgb_precision = train_classifier(xgb, X_train, y_train, X_test, y_test)
# # print(f"SVC Accuracy: {svc_accuracy}, Precision: {svc_precision}")
# # print(f"XGBClassifier Accuracy: {xgb_accuracy}, Precision: {xgb_precision}")
# def train_classifier(clf, X_train, y_train, X_test, y_test):
#     clf.fit(X_train, y_train)
#     y_pred = clf.predict(X_test)
#     accuracy = accuracy_score(y_test, y_pred)
#     precision = precision_score(y_test, y_pred, pos_label='spam')
#     return accuracy, precision

# # Initialize classifiers
# svc = SVC()
# xgb = XGBClassifier()

# # Train and evaluate classifiers
# svc_accuracy, svc_precision = train_classifier(svc, X_train, y_train, X_test, y_test)
# xgb_accuracy, xgb_precision = train_classifier(xgb, X_train, y_train, X_test, y_test)

# # print(f"SVC Accuracy: {svc_accuracy}, Precision: {svc_precision}")
# # print(f"XGBClassifier Accuracy: {xgb_accuracy}, Precision: {xgb_precision}")
# accuracy_score=[]
# precision_score=[]
# for name,clf in clfs.items():
#     current_accuracy,current_precision=train_classifier(clf,X_train,y_train,X_test,y_test)
#     print("for",name)
#     print("Accuracy - ",current_accuracy)
#     print("precision - ",current_precision)
#     accuracy_score.append(current_accuracy)
#     precision_score.append(current_precision)
#     performace_df=pd.DataFrame({'Algorithm':clfs.keys(),'Accuracy':accuracy_score,'Precision':precision_score}).sort_values('Accuracy',ascending=False)
# print(performace_df)
# sns.catplot(x='Algorithm',y='value',hue='variable',data=performance_df1,kind='bar',height=5)
# plt.ylim(0.5,1.0)
# plt.xticks(rotation="vertical")
# plt.show()
# performace_df.merge(temp_df,on='Algorithm')
# #voting classifier
# svc=SVC(kernel='sigmoid',gamma=1.0,probability=True)
# mnb=MultinomialNB()
# etc=ExtraTreesClassifier(n_estimators=50,random_state=2)
# from sklearn.ensemble import VotingClassifier
# voting=VotingClassifier(estimators=[('SVM',SVC),('nb',mnb),('et',etc)],voting='soft')
# voting.fit(X_train,y_train)
# y_pred=voting.predict(X_test)
# print("Accuracy:",accuracy_score(y_test,y_pred))
# print("Predision:",precision_score(y_test,y_pred))
# #Applying stacking
# estimators=[('SVM',svc),('nb',mnb),('et',etc)]
# final_estimators=RandomForestClassifier()
# from sklearn.ensemble import StackingClassifier
# clf=StackingClassifier(estimators=estimators,final_estimator=final_estimators)
# clf.fit(X_train,y_train)
# y_pred=clf.predict(X_test)
# print("Accuracy",accuracy_score(y_pred,y_test))
# print("Precision",precision_score(y_pred,y_test))
# import pickle
# pickle.dump(tfidf,open('vectorizer.pkl','wb'))
# pickle.dump(mnb,open('model.pkl','wb'))


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
from nltk.tokenize import word_tokenize, sent_tokenize
from wordcloud import WordCloud
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB, MultinomialNB, BernoulliNB
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score
import nltk
import string

# Download necessary NLTK data
nltk.download('stopwords')
nltk.download('punkt')

# Load data
df = pd.read_csv('spam.csv')

# Data cleaning
print(df.isnull().sum())
print(df.duplicated().sum())
df = df.drop_duplicates(keep='first')
print(df.shape)

# Exploratory Data Analysis (EDA)
print(df.head())
print(df['Category'].value_counts())

plt.pie(df['Category'].value_counts(), labels=['ham', 'spam'], autopct="%0.2f")
plt.show()

df['num_characters'] = df['Message'].apply(len)
df['num_words'] = df['Message'].apply(lambda x: len(word_tokenize(x)))
df['num_sentences'] = df['Message'].apply(lambda x: len(sent_tokenize(x)))
print(df[['num_characters', 'num_words', 'num_sentences']].describe())

# Histograms
sns.histplot(df[df['Category'] == 'ham']['num_characters'], label='ham', kde=False, color='blue')
sns.histplot(df[df['Category'] == 'spam']['num_characters'], label='spam', kde=False, color='red')
plt.legend()
plt.show()

sns.histplot(df[df['Category'] == 'ham']['num_words'], label='ham', kde=False, color='blue')
sns.histplot(df[df['Category'] == 'spam']['num_words'], label='spam', kde=False, color='red')
plt.legend()
plt.show()

sns.pairplot(df, hue='Category')
plt.show()

# Text preprocessing
ps = PorterStemmer()

def transform_message(message):
    message = message.lower()
    message = word_tokenize(message)
    message = [word for word in message if word.isalnum()]
    message = [word for word in message if word not in stopwords.words('english') and word not in string.punctuation]
    message = [ps.stem(word) for word in message]
    return " ".join(message)

df['transformed_Message'] = df['Message'].apply(transform_message)
print(df.head())

# Wordcloud
wc = WordCloud(width=500, height=500, min_font_size=10, background_color='white')
spam_wc = wc.generate(df[df['Category'] == 'spam']['transformed_Message'].str.cat(sep=" "))
plt.imshow(spam_wc, interpolation='bilinear')
plt.axis('off')
plt.show()

# Frequency distribution for spam and ham messages
spam_corpus = []
for msg in df[df['Category'] == 'spam']['transformed_Message'].tolist():
    for word in msg.split():
        spam_corpus.append(word)

ham_corpus = []
for msg in df[df['Category'] == 'ham']['transformed_Message'].tolist():
    for word in msg.split():
        ham_corpus.append(word)

# Plot most common words
from collections import Counter
spam_counter = pd.DataFrame(Counter(spam_corpus).most_common(30), columns=['word', 'count'])
ham_counter = pd.DataFrame(Counter(ham_corpus).most_common(30), columns=['word', 'count'])

sns.barplot(x='word', y='count', data=spam_counter)
plt.xticks(rotation='vertical')
plt.show()

sns.barplot(x='word', y='count', data=ham_counter)
plt.xticks(rotation='vertical')
plt.show()

# Model building
cv = CountVectorizer()
X = cv.fit_transform(df['transformed_Message']).toarray()

# Encode the target labels
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
y = le.fit_transform(df['Category'])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=2)

# Naive Bayes Models
gnb = GaussianNB()
mnb = MultinomialNB()
bnb = BernoulliNB()

# GaussianNB
gnb.fit(X_train, y_train)
y_pred1 = gnb.predict(X_test)
print('GaussianNB:')
print('Accuracy:', accuracy_score(y_test, y_pred1))
print('Confusion Matrix:', confusion_matrix(y_test, y_pred1))
print('Precision:', precision_score(y_test, y_pred1, pos_label=1))

# MultinomialNB
mnb.fit(X_train, y_train)
y_pred2 = mnb.predict(X_test)
print('MultinomialNB:')
print('Accuracy:', accuracy_score(y_test, y_pred2))
print('Confusion Matrix:', confusion_matrix(y_test, y_pred2))
print('Precision:', precision_score(y_test, y_pred2, pos_label=1))

# BernoulliNB
bnb.fit(X_train, y_train)
y_pred3 = bnb.predict(X_test)
print('BernoulliNB:')
print('Accuracy:', accuracy_score(y_test, y_pred3))
print('Confusion Matrix:', confusion_matrix(y_test, y_pred3))
print('Precision:', precision_score(y_test, y_pred3, pos_label=1))

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.ensemble import GradientBoostingClassifier
from xgboost import XGBClassifier

# Classifier initialization
svc = SVC(kernel='sigmoid', gamma=1.0)
knc = KNeighborsClassifier()
mnb = MultinomialNB()
dtc = DecisionTreeClassifier(max_depth=5)
lrc = LogisticRegression(solver='liblinear', penalty='l1')
rfc = RandomForestClassifier(n_estimators=50, random_state=2)
abc = AdaBoostClassifier(n_estimators=50, random_state=2)
bc = BaggingClassifier(n_estimators=50, random_state=2)
etc = ExtraTreesClassifier(n_estimators=50, random_state=2)
gbdt = GradientBoostingClassifier(n_estimators=50, random_state=2)
xgb = XGBClassifier(n_estimators=50, random_state=2)

clfs = {
    'SVC': svc,
    'KN': knc,
    'NB': mnb,
    'DT': dtc,
    'LR': lrc,
    'RF': rfc,
    'AdaBoost': abc,
    'Bgc': bc,
    'ETC': etc,
    'GBDT': gbdt,
    'xgb': xgb
}

def train_classifier(clf, X_train, y_train, X_test, y_test):
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    return accuracy, precision

accuracy_scores = []
precision_scores = []

for name, clf in clfs.items():
    current_accuracy, current_precision = train_classifier(clf, X_train, y_train, X_test, y_test)
    print(f'For {name}:')
    print('Accuracy -', current_accuracy)
    print('Precision -', current_precision)
    accuracy_scores.append(current_accuracy)
    precision_scores.append(current_precision)

performance_df = pd.DataFrame({'Algorithm': clfs.keys(), 'Accuracy': accuracy_scores, 'Precision': precision_scores}).sort_values('Accuracy', ascending=False)
print(performance_df)

sns.catplot(x='Algorithm', y='value', hue='variable', data=pd.melt(performance_df, id_vars='Algorithm'), kind='bar', height=5)
plt.ylim(0.5, 1.0)
plt.xticks(rotation='vertical')
plt.show()

# Voting classifier
svc = SVC(kernel='sigmoid', gamma=1.0, probability=True)
mnb = MultinomialNB()
etc = ExtraTreesClassifier(n_estimators=50, random_state=2)
from sklearn.ensemble import VotingClassifier
voting = VotingClassifier(estimators=[('SVM', svc), ('nb', mnb), ('et', etc)], voting='soft')
voting.fit(X_train, y_train)
y_pred = voting.predict(X_test)
print("Voting Classifier:")
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred))

# Applying stacking
estimators = [('SVM', svc), ('nb', mnb), ('et', etc)]
final_estimator = RandomForestClassifier()
from sklearn.ensemble import StackingClassifier
clf = StackingClassifier(estimators=estimators, final_estimator=final_estimator)
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)
print("Stacking Classifier:")
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred))

import pickle
pickle.dump(cv, open('vectorizer.pkl', 'wb'))
pickle.dump(mnb, open('model.pkl', 'wb'))

