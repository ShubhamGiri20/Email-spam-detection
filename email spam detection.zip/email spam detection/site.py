# import streamlit as st
# import pickle
# import string
# from nltk.corpus import stopwords
# def transform_Message(Message):
#   Message=Message.lower()
#   Message=nltk.word_tokenize(Message)
#   y=[]   
#   for i in Message:
#       if i.isalnum():
#           y.append(i)
#   Message=y[:]
#   y.clear()
#   for i in Message:
#      if i not in stopwords.words('english') and i not in string.punctuation:
#         y.append(i)
#   Message=y[:]
#   y.clear()
#   for i in Message:
#       y.append(ps.stem(i))
#   return " ".join(y)


# tfidf =pickle.load(open('vectorizer.pkl','rb'))
# model=pickle.load(open('model.pkl','rb'))
# st.title("Email/SMS spam Classifer")
# input_sms=st.text_input("Enter the message")
# # 1.preprocess
# transformed_sms=transformed_text(input_sms)
# #2.vectorize
# vector_input=tfidf.transformed([transformed_sms])
# #3.predict
# result=model.predict(vector_input)[0]
# #4.display
# if result==1:
#     st.header("Spam")
# else:
#     st.header("Not Spam")
# import streamlit as st
# import pickle
# import string
# import nltk
# from nltk.corpus import stopwords
# from nltk.stem.porter import PorterStemmer

# # Download NLTK resources
# nltk.download('punkt')
# nltk.download('stopwords')

# # Function for text preprocessing
# def transform_Message(Message):
#     ps = PorterStemmer()
#     Message = Message.lower()
#     Message = nltk.word_tokenize(Message)
#     y = []
#     for i in Message:
#         if i.isalnum():
#             y.append(i)
#     Message = y[:]
#     y.clear()
#     for i in Message:
#         if i not in stopwords.words('english') and i not in string.punctuation:
#             y.append(i)
#     Message = y[:]
#     y.clear()
#     for i in Message:
#         y.append(ps.stem(i))
#     return " ".join(y)

# # Load saved model and vectorizer
# tfidf = pickle.load(open('vectorizer.pkl', 'rb'))
# model = pickle.load(open('model.pkl', 'rb'))

# # Streamlit app
# st.title("Email/SMS Spam Classifier")
# input_sms = st.text_input("Enter the message")

# if st.button("Predict"):
#     if input_sms:
#         # Preprocess the input message
#         transformed_sms = transform_Message(input_sms)
        
#         # Vectorize the input message
#         vector_input = tfidf.transform([transformed_sms])
        
#         # Predict using the model
#         result = model.predict(vector_input)[0]
        
#         # Display prediction
#         if result == 1:
#             st.header("Spam")
#         else:
#             st.header("Not Spam")
#     else:
#         st.warning("Please enter a message to classify.")
